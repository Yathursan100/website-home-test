<?php
/**
 * Database Configuration
 */

return [
    'host' => 'localhost',
    'dbname' => 'phpdeveloper',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4'
];

